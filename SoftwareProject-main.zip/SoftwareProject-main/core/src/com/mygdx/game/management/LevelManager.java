package com.mygdx.game.management;

public class LevelManager {
}
