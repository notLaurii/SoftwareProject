package com.mygdx.game.management;

public class GameManager {


    public void update(float delta) {

    }
}

