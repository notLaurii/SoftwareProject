package com.mygdx.game.entities;
public class EntityData {
    public String type;
    public float x;
    public float y;
    public float health;
    public float attackDamage;
}