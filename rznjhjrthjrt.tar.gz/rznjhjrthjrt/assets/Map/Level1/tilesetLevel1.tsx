<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tileset" tilewidth="16" tileheight="16" tilecount="60" columns="15">
 <image source="tilesetLevel1.png" width="240" height="64"/>
</tileset>
