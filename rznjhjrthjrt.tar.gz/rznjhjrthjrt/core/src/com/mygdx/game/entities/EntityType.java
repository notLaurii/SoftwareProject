package com.mygdx.game.entities;

import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.reflect.ClassReflection;
import com.badlogic.gdx.utils.reflect.ReflectionException;

import com.mygdx.game.world.GameMap;


public enum EntityType {

	PLAYER("player", 16, 24, 40),
	SLIME("slime", 12, 12, 30),
	GOBLIN("goblin",  20, 20, 50),
	SHOP("shop", 16, 37, 40),
	MAGICAN("magican", 16,14,30),
	BIRD("bird",24,16,0),
	EGG("egg",10,10,50),
	PEARL("pearl",5,5,0),
	ELF("elf",16,24,40),
	BOOMERANG("boomerang", 12, 12, 0),
	DONUTPROJECTILE("donutprojectile", 16, 16, 0),
	TNT("tnt",16,16,20),
	GOLD("gold",  8,8,30);

	private String id;
	//private Class loaderClass;
	private int width, height;
	private float weight;

	private EntityType(String id, int width, int height, float weight) {
		this.id = id;
		//this.loaderClass = loaderClass;
		this.width = width;
		this.height = height;
		this.weight = weight;
	}

	public String getId() {
		return id;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public float getWeight() {
		return weight;
	}

}
