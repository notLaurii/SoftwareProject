package com.mygdx.game.entities.enemies;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Timer;
import com.mygdx.game.entities.EntityType;
import com.mygdx.game.entities.Player;
import com.mygdx.game.entities.enemies.Enemy;
import com.mygdx.game.management.LevelManager;
import com.mygdx.game.world.GameMap;

import java.util.Objects;

import static com.mygdx.game.management.MyGdxGame.levelManager;

public class Goblin extends Enemy {

    private static float speed;
    private static float jumpVelocity;
    private float playerDetectionRangeX = 182; // Anpassung der Verfolgungsdistanz
    private float playerDetectionRangeY = 64;
    private float attackRangeX = 50;
    private boolean canAct = true;
    private Texture image;
    private Texture sword;
    private boolean swordSwinging = false;
    private boolean canJump = true; // Fügt die Möglichkeit zum Springen hinzu

    public Goblin(float x, float y, GameMap map, float health, float attackDamage, float speed, float jumpVelocity, String WeaponID) {
        super(x, y, EntityType.GOBLIN, map, health, attackDamage, 12);
        this.speed = speed;
        this.jumpVelocity = jumpVelocity;
        image = new Texture("Entity/Enemy/Goblin/goblin.png");
    }

    @Override
    public void update(float deltaTime, float gravity) {
        super.update(deltaTime, gravity);
        verfolgen();
        angreifen();
    }

    public void verfolgen() {
        if(levelManager.getPlayer() != null && levelManager.getPlayer().getHealth() > 0) {
            float x = levelManager.getPlayer().getX() - getX();
            if (x > 10) {
                moveX(1f);
                setDirection("Right");
            } else if (x < -10) {
                moveX(-1f);
                setDirection("Left");
            } else {
                moveX(0);
            }

            float y = levelManager.getPlayer().getY() - getY();
            if(y > 0 && isGrounded() && canJump && levelManager.getPlayer().getHealth() > 0){
                this.velocityY += jumpVelocity * getWeight();
                canJump = false;
                Timer.schedule(new Timer.Task() {
                    @Override
                    public void run() {
                        canJump = true;
                    }
                }, 2); // Sprung-Cooldown
            }
        }
    }

    public void angreifen() {
        if (levelManager.getPlayer() != null && levelManager.getPlayer().getHealth() > 0) {
            float x = levelManager.getPlayer().getX() - getX();
            float y = levelManager.getPlayer().getY() - getY();

            if (Math.abs(x) < attackRangeX && Math.abs(y) < playerDetectionRangeY && canAct) {
                // Der Goblin führt den Angriff aus
                swordSwinging = true;
                levelManager.getPlayer().setHealth(levelManager.getPlayer().getHealth() - attackDamage);
                System.out.println("Schwertangriff!");

                // Deaktiviert weitere Aktionen und startet den Cooldown
                canAct = false;
                Timer.schedule(new Timer.Task() {
                    @Override
                    public void run() {
                        // Cooldown abgelaufen, erlaubt wieder Aktionen
                        canAct = true;
                        swordSwinging = false;
                    }
                }, 0.01F); // Cooldown-Zeit in Sekunden
            }
        }
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
        if (swordSwinging) {
            // Logik zum Zeichnen des Schwerts während des Angriffs hinzufügen
            // Zum Beispiel könnte das Schwertbild neben dem Goblin angezeigt werden, abhängig von der Richtung des Angriffs
        }
        super.render(batch);
    }

}
