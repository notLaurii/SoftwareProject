package com.mygdx.game.entities.projectiles;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.entities.Entity;
import com.mygdx.game.entities.EntityType;
import com.mygdx.game.entities.Player;
import com.mygdx.game.management.LevelManager;
import com.mygdx.game.world.GameMap;

import java.util.ArrayList;
import java.util.Objects;

import static com.mygdx.game.management.MyGdxGame.levelManager;

// Definition der BoomerangProjectile-Klasse, die von der Klasse Projectile erbt.
public class BoomerangProjectile extends Projectile {

    // Klassenvariablen, die verschiedene Eigenschaften des Boomerangs definieren.
    private static final int speed = 500; // Grundgeschwindigkeit des Boomerangs.
    private float airTime = 0; // Verstrichene Zeit seit dem Werfen des Boomerangs.
    private float maxAirTime = 5; // Maximale Zeit, die der Boomerang in der Luft bleiben kann.
    private float normalAirTime = 2.5f; // Normale Zeit für eine Hin- und Rückreise des Boomerangs.
    private Texture image; // Bild des Boomerangs.
    private float damage; // Schaden, den der Boomerang verursachen kann.
    private float currentSpeed = speed; // Aktuelle Geschwindigkeit des Boomerangs.
    private String direction; // Richtung des Boomerangs.
    private float rotation = 0f; // Aktuelle Rotation des Boomerangs.

    // Konstruktor der Klasse, initialisiert den Boomerang mit einem Standort, Typ, Schaden und Bild.
    public BoomerangProjectile(GameMap map, Entity shooter, float damage) {
        super(shooter.getX(), shooter.getY(), EntityType.BOOMERANG, map, 0, shooter);
        this.damage = damage;
        this.image = new Texture("Entity/Projectile/boomerangProjectile.png");
        this.direction = getShooter().getDirection();
    }

    // Update-Methode, die den Zustand des Boomerangs jede Spielaktualisierung ändert.
    @Override
    public void update(float deltaTime, float gravity) {
        rotation += 10 * 360 * deltaTime / normalAirTime; // Aktualisiert die Rotation des Boomerangs.
        checkHit(damage); // Überprüft, ob der Boomerang ein Ziel getroffen hat.
        super.update(deltaTime, gravity); // Ruft die Update-Methode der Elternklasse auf.
        airTime += deltaTime; // Aktualisiert die verstrichene Zeit.
        if (airTime >= maxAirTime) // Entfernt den Boomerang, wenn die maximale Luftzeit überschritten ist.
            levelManager.entitiesToRemove.add(this);
        currentSpeed -= speed * deltaTime / (normalAirTime / 2); // Aktualisiert die Geschwindigkeit des Boomerangs.
        float delta = currentSpeed * deltaTime; // Berechnet die Distanzveränderung.

        // Bewegungslogik des Boomerangs abhängig von seiner Richtung und Kollision mit der Umgebung.
        if (Objects.equals(this.direction, "Left")) {
            if (map.doesEntityCollideWithMap(getX() - delta, getY(), getWidth(), getHeight())) {
                if (airTime < normalAirTime / 2) {
                    airTime = normalAirTime / 2;
                    currentSpeed = 0;
                }
            }
            if (airTime > normalAirTime / 2 && (this.getX() > shooter.getX() || map.doesEntityCollideWithMap(getX() - delta, getY(), getWidth(), getHeight())))
                levelManager.entitiesToRemove.add(this);
            moveX(-delta);
        } else {
            if (map.doesEntityCollideWithMap(getX() + delta, getY(), getWidth(), getHeight())) {
                if (airTime < normalAirTime / 2) {
                    airTime = normalAirTime / 2;
                    currentSpeed = 0;
                } else levelManager.entitiesToRemove.add(this);
            }
            if (airTime > normalAirTime / 2 && (this.getX() < shooter.getX() || map.doesEntityCollideWithMap(getX() - delta, getY(), getWidth(), getHeight())))
                levelManager.entitiesToRemove.add(this);
            moveX(delta);
        }

        // Zusätzliche Logik für die Y-Achsen-Bewegung
        if (airTime > normalAirTime / 2) {
            float yDelta = shooter.getY() - getY(); // Differenz zwischen Spieler Y-Position und Boomerang Y-Position.
            // Berechnung der entgegengesetzten Y-Bewegung.
            if (Math.abs(yDelta) > 1) {
                // Invertiert die Richtung der Y-Bewegung basierend auf der aktuellen Position relativ zum Spieler.
                yDelta = -Math.signum(yDelta) * Math.min(Math.abs(yDelta), currentSpeed * deltaTime / 2);
            } else {
                // Wenn die Y-Distanz sehr klein ist, bewegt sich der Boomerang direkt zum Spieler, um kleine Unstimmigkeiten zu vermeiden.
                yDelta = shooter.getY() - getY();
            }
            moveY(yDelta);
        }


    }

    // Render-Methode, zeichnet den Boomerang auf dem Bildschirm basierend auf seiner Position und Rotation.
    @Override
    public void render(SpriteBatch batch) {
        float originX = getWidth() / 2f; // Mittelpunkt der Breite für die Rotation.
        float originY = getHeight() / 2f; // Mittelpunkt der Höhe für die Rotation.

        // Zeichnet den Boomerang mit der aktuellen Rotation.
        batch.draw(image, pos.x, pos.y, originX, originY, getWidth(), getHeight(), 1f, 1f, rotation, 0, 0, image.getWidth(), image.getHeight(), false, false);
    }
}





