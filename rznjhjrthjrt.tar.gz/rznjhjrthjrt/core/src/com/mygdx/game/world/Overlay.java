package com.mygdx.game.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.entities.Player;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import static com.mygdx.game.management.MyGdxGame.levelManager;

// Die Overlay-Klasse bietet eine grafische Oberfläche (UI) über das Spielgeschehen.
public class Overlay {
    // Deklaration der Variablen für die UI-Elemente.
    private BitmapFont font; // Schriftart für Textdarstellungen.
    private SpriteBatch batch; // Zum Zeichnen von Texturen und Texten in Batches.
    private Texture goldIconTexture; // Textur für das Gold-Icon.
    private boolean visible; // Bestimmt, ob das Overlay sichtbar ist.
    private ShapeRenderer shapeRenderer; // Zum Zeichnen von Formen wie Lebensbalken.

    // Konstruktor der Overlay-Klasse, initialisiert die Variablen und lädt Ressourcen.
    public Overlay() {
        font = new BitmapFont(); // Initialisiert die BitmapFont-Instanz.
        batch = new SpriteBatch(); // Initialisiert die SpriteBatch-Instanz.
        goldIconTexture = new Texture("Interfaces/goldmünze.png"); // Lädt die Gold-Icon-Textur.
        visible = true; // Setzt das Overlay standardmäßig auf sichtbar.
        shapeRenderer = new ShapeRenderer(); // Initialisiert den ShapeRenderer für Formen.
    }

    // Die Render-Methode, zeichnet die UI-Elemente, wenn das Overlay sichtbar ist.
    public void render() {
        if (!visible) return; // Überspringt das Zeichnen, wenn das Overlay nicht sichtbar ist.

        batch.begin(); // Beginnt das Batch-Zeichnen für Texturen und Text.

        // Ermittelt die Spielerposition für die Koordinatenanzeige.
        float x = levelManager.getPlayer().getX();
        float y = levelManager.getPlayer().getY();

        // Zeichnet Spielerkoordinaten in Rot und setzt weitere UI-Elemente wie die Goldmenge.
        font.setColor(Color.RED);
        font.draw(batch, "x: " + x, 20, 420); // Zeichnet die X-Koordinate des Spielers.
        font.draw(batch, "y: " + y, 20, 400); // Zeichnet die Y-Koordinate des Spielers.
        font.setColor(Color.WHITE); // Setzt die Schriftfarbe zurück auf Weiß für folgende Texte.

        // Goldanzeige: Zeichnet das Gold-Icon und daneben die Menge des Goldes des Spielers in Gelb.
        font.setColor(Color.YELLOW);
        batch.draw(goldIconTexture, 20, 438, 12, 12); // Zeichnet das Gold-Icon.
        font.draw(batch, "" + levelManager.getPlayer().getGoldAmount(), 35, 450); // Zeichnet die Goldmenge.
        font.setColor(Color.WHITE); // Setzt die Schriftfarbe zurück auf Weiß.

        // Einfache Textbuttons für Einstellungen und Inventar, ohne Funktionalität in diesem Code-Ausschnitt.
        font.draw(batch, "Einstellungen", 540, 450);
        font.draw(batch, "Inventar", 450, 450);

        // Zeichnet Platzhalter für Waffen- und Fähigkeitenslots.
        font.draw(batch, "Slot 1", 525, 50); // Waffenslot 1
        font.draw(batch, "Slot 2", 575, 50); // Waffenslot 2
        font.draw(batch, "Slot 1", 400, 50); // Fähigkeitenslot 1
        font.draw(batch, "Slot 2", 450, 50); // Fähigkeitenslot 2

        batch.end(); // Beendet das Batch-Zeichnen.

        // Zeichnen des Lebensbalkens mit ShapeRenderer.
        float healthBarWidth = 200;
        float healthBarHeight = 20;
        shapeRenderer.begin(ShapeType.Filled); // Beginnt das Füllen der Formen.
        shapeRenderer.setColor(Color.DARK_GRAY); // Hintergrund des Lebensbalkens.
        shapeRenderer.rect(25, 30, healthBarWidth, healthBarHeight); // Zeichnet den Hintergrund.
        float currentHealth = levelManager.getPlayer().getHealth(); // Aktuelle Lebenspunkte.
        float maxHealth = levelManager.getPlayer().getMaxHealth(); // Maximale Lebenspunkte.
        float healthPercentage = currentHealth / maxHealth; // Berechnet den Prozentsatz der verbleibenden Gesundheit.
        shapeRenderer.setColor(Color.GREEN); // Setzt die Farbe für den aktuellen Gesundheitszustand.
        shapeRenderer.rect(25, 30, healthBarWidth * healthPercentage, healthBarHeight); // Zeichnet den aktuellen Lebensbalken.
        shapeRenderer.end(); // Beendet das Zeichnen der Formen.

        // Zeichnet den Text für die Lebenspunkte über dem Lebensbalken.
        batch.begin(); // Beginnt erneut das Batch-Zeichnen für den Text.
        String healthText = String.format("%.0f / %.0f", currentHealth, maxHealth); // Text für die Lebenspunkte.
        font.setColor(Color.BLACK); // Setzt die Textfarbe.
        // Berechnet die Position und zeichnet den Text zentriert über dem Lebensbalken.
        float textWidth = font.getSpaceXadvance() * healthText.length();
        float textX = 25 + (healthBarWidth - textWidth) / 2;
        float textY = 30 + healthBarHeight / 2 + font.getLineHeight() / 2;
        font.draw(batch, healthText, textX, textY);
        batch.end(); // Beendet das Zeichnen des Textes.
    }

    // Methode zum Setzen der Sichtbarkeit des Overlays.
    public void setVisible(boolean visible) {
        this.visible = visible; // Setzt die Sichtbarkeitsvariable entsprechend.
    }
}
